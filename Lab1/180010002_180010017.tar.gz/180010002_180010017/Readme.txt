Commands to run:-
    For compilation             :     make my_shell
    To run in batch mode        :     ./my_shell commands.txt
    To run in interactive mode  :     ./my_shell