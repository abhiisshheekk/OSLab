Commands to run:-
	for test_alloc -
	Compile : make alloc
	Run		: ./alloc
	
	for test_ealloc -
    Compile : make ealloc
	Run		: ./ealloc