Compilation:    $ gcc <testcase.c> simplefs-disk.c simplefs-ops.c -o simplefs
Run:            $ ./simplefs

To run all the testcases: 
                $ ./autograder.sh testcases expected_output